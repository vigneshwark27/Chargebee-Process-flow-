import React from "react";
import { motion } from "motion/react";
import {
  User,
  Cpu,
  Database,
  ArrowDown,
  Layout,
  RefreshCcw,
  Zap,
  CheckCircle2,
} from "lucide-react";

type LaneType = "user" | "system" | "ai";
type ShapeType =
  | "rounded-rect"
  | "rect"
  | "diamond"
  | "parallelogram";

interface FlowStep {
  id: string;
  lane: LaneType;
  type: ShapeType;
  label: string;
  details?: string[];
  subLabel?: string;
  isTerminal?: boolean;
}

const FLOW_STEPS: FlowStep[] = [
  {
    id: "start",
    lane: "user",
    type: "rounded-rect",
    label: "Navigate to Contracts module",
  },
  {
    id: "upload",
    lane: "user",
    type: "rounded-rect",
    label: "Upload signed contract PDF",
  },
  {
    id: "store-contract",
    lane: "system",
    type: "parallelogram",
    label: "Securely store contract",
  },
  {
    id: "send-to-ai",
    lane: "system",
    type: "rect",
    label: "Send contract to AI Extraction Engine",
  },
  {
    id: "ai-extract",
    lane: "ai",
    type: "rect",
    label: "Extract subscription terms",
    details: [
      "Customer",
      "Plan",
      "Quantity",
      "Billing Frequency",
      "Start Date",
      "End Date",
      "Pricing",
      "Discounts",
    ],
  },
  {
    id: "ai-return",
    lane: "ai",
    type: "rect",
    label: "Return structured data to System",
  },
  {
    id: "create-draft",
    lane: "system",
    type: "rect",
    label: "Immediately create Draft Subscription record",
    subLabel:
      "Status: Draft – Not Active, Pre-filled with extracted data",
  },
  {
    id: "redirect-review",
    lane: "system",
    type: "rect",
    label:
      "Redirect to Draft Subscription page in Subscriptions module",
  },
  {
    id: "highlight-fields",
    lane: "system",
    type: "rect",
    label: "Highlight skeptical / ambiguous fields",
  },
  {
    id: "decision-data",
    lane: "system",
    type: "diamond",
    label: "Mandatory data missing?",
  },
  {
    id: "decision-master",
    lane: "system",
    type: "diamond",
    label: "Master data exists?",
  },
  {
    id: "create-master-link",
    lane: "user",
    type: "rounded-rect",
    label: "Click link near field to create master data",
    subLabel: "Customer or Plan master",
  },
  {
    id: "redirect-master",
    lane: "system",
    type: "rect",
    label: "Redirect to Master Data creation page",
  },
  {
    id: "fill-master",
    lane: "user",
    type: "rounded-rect",
    label: "Fill master data and save",
  },
  {
    id: "select-master",
    lane: "user",
    type: "rounded-rect",
    label: "Select created master data",
  },
  {
    id: "return-draft",
    lane: "system",
    type: "rect",
    label: "Return to Draft Subscription page",
  },
  {
    id: "review-fields",
    lane: "user",
    type: "rounded-rect",
    label: "Review pre-filled fields",
  },
  {
    id: "view-contract",
    lane: "user",
    type: "rounded-rect",
    label: "View contract PDF side-by-side",
    subLabel: "with highlighted keywords",
  },
  {
    id: "confirm",
    lane: "user",
    type: "rounded-rect",
    label: 'Click "Confirm & Create Subscription"',
  },
  {
    id: "convert-active",
    lane: "system",
    type: "rect",
    label: "Convert Draft → Active Subscription",
  },
  {
    id: "lifecycle",
    lane: "system",
    type: "rect",
    label: "Begin standard subscription lifecycle",
    details: ["Invoicing", "Payments", "Renewals"],
  },
  {
    id: "link-reference",
    lane: "system",
    type: "parallelogram",
    label: "Store contract as read-only reference",
    isTerminal: true,
  },
];

const Shape = ({
  type,
  label,
  lane,
  details,
  subLabel,
}: {
  type: ShapeType;
  label: string;
  lane: LaneType;
  details?: string[];
  subLabel?: string;
}) => {
  const bgColor = {
    user: "bg-indigo-50 border-indigo-200 text-indigo-900",
    system: "bg-slate-50 border-slate-200 text-slate-900",
    ai: "bg-violet-50 border-violet-200 text-violet-900",
  }[lane];

  const iconColor = {
    user: "text-indigo-600",
    system: "text-slate-600",
    ai: "text-violet-600",
  }[lane];

  if (type === "diamond") {
    return (
      <div className="relative w-44 h-44 flex items-center justify-center group">
        <div
          className={`absolute inset-0 border-2 rotate-45 transform transition-transform group-hover:scale-105 bg-white border-slate-300 shadow-sm`}
        />
        <div className="relative z-10 text-center p-6 font-bold text-xs uppercase tracking-tight text-slate-700 leading-snug">
          {label}
        </div>
        <div className="absolute right-0 top-1/2 translate-x-12 -translate-y-1/2 px-2 py-1 bg-emerald-100 text-[10px] font-bold text-emerald-700 rounded-md border border-emerald-200 shadow-sm">
          YES
        </div>
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-8 px-2 py-1 bg-amber-100 text-[10px] font-bold text-amber-700 rounded-md border border-amber-200 shadow-sm">
          NO
        </div>
      </div>
    );
  }

  if (type === "parallelogram") {
    return (
      <div className="relative w-72 group">
        <div
          className={`absolute inset-0 border-2 -skew-x-12 transform transition-all group-hover:scale-[1.02] ${bgColor}`}
        />
        <div className="relative z-10 p-5 flex items-center gap-4">
          <div
            className={`p-2 rounded-lg bg-white/50 border border-current/10 shadow-sm`}
          >
            <Database
              className={`w-5 h-5 shrink-0 ${iconColor}`}
            />
          </div>
          <div className="text-sm font-bold uppercase tracking-wide">
            {label}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`
      relative w-72 border-2 p-5 transition-all hover:shadow-lg group
      ${type === "rounded-rect" ? "rounded-3xl" : "rounded-lg"}
      ${bgColor}
    `}
    >
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-3">
          <div
            className={`p-2 rounded-xl bg-white/60 border border-current/5 shadow-sm`}
          >
            {lane === "user" && (
              <User
                className={`w-5 h-5 shrink-0 ${iconColor}`}
              />
            )}
            {lane === "ai" && (
              <Cpu
                className={`w-5 h-5 shrink-0 ${iconColor}`}
              />
            )}
            {lane === "system" && (
              <Layout
                className={`w-5 h-5 shrink-0 ${iconColor}`}
              />
            )}
          </div>
          <div className="text-sm font-bold leading-tight uppercase tracking-tight">
            {label}
          </div>
        </div>

        {subLabel && (
          <div className="text-[11px] font-medium opacity-60 italic bg-white/30 px-2 py-1 rounded-lg">
            {subLabel}
          </div>
        )}

        {details && (
          <div className="mt-2 grid grid-cols-2 gap-2 bg-white/40 p-3 rounded-2xl border border-current/5">
            {details.map((detail, i) => (
              <div
                key={i}
                className="text-[10px] font-semibold flex items-center gap-2 text-slate-600"
              >
                <div
                  className={`w-1.5 h-1.5 rounded-full ${iconColor.replace("text", "bg")} opacity-40`}
                />
                {detail}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

function ArrowConnector({
  fromLane,
  toLane,
}: {
  fromLane: LaneType;
  toLane: LaneType;
}) {
  const laneX = {
    user: "16.666%",
    system: "50%",
    ai: "83.333%",
  };

  const x1 = laneX[fromLane];
  const x2 = laneX[toLane];

  if (fromLane === toLane) {
    return (
      <line
        x1={x1}
        y1="0"
        x2={x2}
        y2="100%"
        stroke="#cbd5e1"
        strokeWidth="2"
        markerEnd="url(#arrowhead)"
      />
    );
  }

  return (
    <path
      d={`M ${x1} 0 C ${x1} 50, ${x2} 50, ${x2} 100`}
      fill="none"
      stroke="#cbd5e1"
      strokeWidth="2"
      markerEnd="url(#arrowhead)"
    />
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 p-8 pb-48">
      <div className="max-w-6xl mx-auto">
        <header className="mb-12 bg-white p-10 rounded-[40px] border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <RefreshCcw className="w-48 h-48" />
          </div>
          <div className="relative z-10">
            <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 mb-4 uppercase">
              Contract → Subscription
            </h1>
            <p className="text-slate-500 text-lg max-w-2xl font-medium leading-relaxed">
              Vertical swimlane process flow for automated
              extraction and verification inside the
              subscription billing system.
            </p>

            <div className="flex flex-wrap gap-4 mt-8">
              <div className="flex items-center gap-3 text-[10px] font-black text-violet-700 bg-violet-100 px-5 py-2.5 rounded-2xl border border-violet-200 uppercase tracking-widest">
                <Zap className="w-4 h-4" />
                AI involvement ends at Draft creation
              </div>
              <div className="flex items-center gap-3 text-[10px] font-black text-indigo-700 bg-indigo-100 px-5 py-2.5 rounded-2xl border border-indigo-200 uppercase tracking-widest">
                <User className="w-4 h-4" />
                Human confirmation required before activation
              </div>
              <div className="flex items-center gap-3 text-[10px] font-black text-slate-700 bg-slate-100 px-5 py-2.5 rounded-2xl border border-slate-200 uppercase tracking-widest">
                <RefreshCcw className="w-4 h-4" />
                Existing subscription flow reused
              </div>
            </div>
          </div>
        </header>

        <div className="bg-white rounded-[40px] border border-slate-200 shadow-xl overflow-hidden relative">
          <div className="grid grid-cols-3 bg-slate-50/80 backdrop-blur-sm sticky top-0 z-20 border-b border-slate-200">
            <div className="p-6 text-center border-r border-slate-200">
              <div className="flex items-center justify-center gap-3 mb-1">
                <div className="p-1.5 rounded-lg bg-indigo-100">
                  <User className="w-5 h-5 text-indigo-600" />
                </div>
                <span className="font-black text-indigo-900 uppercase tracking-widest text-sm">
                  User
                </span>
              </div>
              <div className="text-[10px] text-indigo-500 font-bold uppercase tracking-widest opacity-70">
                Billing / Revenue Ops
              </div>
            </div>
            <div className="p-6 text-center border-r border-slate-200">
              <div className="flex items-center justify-center gap-3 mb-1">
                <div className="p-1.5 rounded-lg bg-slate-200">
                  <Layout className="w-5 h-5 text-slate-700" />
                </div>
                <span className="font-black text-slate-900 uppercase tracking-widest text-sm">
                  System
                </span>
              </div>
              <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest opacity-70">
                Application Core
              </div>
            </div>
            <div className="p-6 text-center">
              <div className="flex items-center justify-center gap-3 mb-1">
                <div className="p-1.5 rounded-lg bg-violet-100">
                  <Cpu className="w-5 h-5 text-violet-600" />
                </div>
                <span className="font-black text-violet-900 uppercase tracking-widest text-sm">
                  AI Engine
                </span>
              </div>
              <div className="text-[10px] text-violet-500 font-bold uppercase tracking-widest opacity-70">
                Extraction Engine
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 relative py-20 bg-white">
            <div className="absolute inset-y-0 left-1/3 w-px bg-slate-100" />
            <div className="absolute inset-y-0 left-2/3 w-px bg-slate-100" />

            {FLOW_STEPS.map((step, index) => {
              const prevStep =
                index > 0 ? FLOW_STEPS[index - 1] : null;

              return (
                <div key={step.id} className="contents">
                  {index > 0 && (
                    <div className="col-span-3 h-24 relative overflow-visible">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <svg
                          className="w-full h-full overflow-visible pointer-events-none"
                          viewBox="0 0 100 100"
                          preserveAspectRatio="none"
                        >
                          <defs>
                            <marker
                              id="arrowhead"
                              markerWidth="10"
                              markerHeight="7"
                              refX="9"
                              refY="3.5"
                              orient="auto"
                            >
                              <polygon
                                points="0 0, 10 3.5, 0 7"
                                fill="#cbd5e1"
                              />
                            </marker>
                          </defs>
                          {prevStep && (
                            <ArrowConnector
                              fromLane={prevStep.lane}
                              toLane={step.lane}
                            />
                          )}
                        </svg>
                      </div>
                    </div>
                  )}

                  <div
                    className={`flex justify-center items-center z-10 ${
                      step.lane === "user"
                        ? "col-start-1"
                        : step.lane === "system"
                          ? "col-start-2"
                          : "col-start-3"
                    }`}
                  >
                    <motion.div
                      initial={{
                        opacity: 0,
                        scale: 0.9,
                        y: 30,
                      }}
                      whileInView={{
                        opacity: 1,
                        scale: 1,
                        y: 0,
                      }}
                      viewport={{ once: true, margin: "-50px" }}
                      transition={{
                        type: "spring",
                        damping: 20,
                        stiffness: 100,
                      }}
                    >
                      <Shape
                        type={step.type}
                        label={step.label}
                        lane={step.lane}
                        details={step.details}
                        subLabel={step.subLabel}
                      />
                    </motion.div>
                  </div>

                  {step.id === "decision-data" && (
                    <div className="col-span-3 h-24 relative overflow-visible">
                      <svg
                        className="w-full h-full overflow-visible pointer-events-none"
                        viewBox="0 0 100 100"
                        preserveAspectRatio="none"
                      >
                        <path
                          d="M 50 50 L 16.66 50 L 16.66 0"
                          fill="none"
                          stroke="#fbbf24"
                          strokeWidth="0.5"
                          strokeDasharray="1.5 1"
                          markerEnd="url(#arrowhead)"
                        />
                        <text
                          x="33.33"
                          y="40"
                          textAnchor="middle"
                          fontSize="2"
                          className="fill-amber-500 font-black uppercase tracking-widest"
                        >
                          NO: Prompt User
                        </text>
                      </svg>
                    </div>
                  )}

                  {step.id === "decision-master" && (
                    <div className="col-span-3 h-24 relative overflow-visible">
                      <svg
                        className="w-full h-full overflow-visible pointer-events-none"
                        viewBox="0 0 100 100"
                        preserveAspectRatio="none"
                      >
                        <path
                          d="M 50 50 L 16.66 50 L 16.66 100"
                          fill="none"
                          stroke="#fbbf24"
                          strokeWidth="0.5"
                          strokeDasharray="1 1"
                          markerEnd="url(#arrowhead)"
                        />
                        <text
                          x="33.33"
                          y="75"
                          textAnchor="middle"
                          fontSize="2"
                          className="fill-amber-500 font-black uppercase tracking-widest"
                        >
                          NO: Create Master
                        </text>
                      </svg>
                    </div>
                  )}

                  {step.id === "return-draft" && (
                    <div className="col-span-3 h-24 relative overflow-visible">
                      <svg
                        className="w-full h-full overflow-visible pointer-events-none"
                        viewBox="0 0 100 100"
                        preserveAspectRatio="none"
                      >
                        <path
                          d="M 50 0 L 50 50"
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="0.5"
                          strokeDasharray="1.5 1"
                          markerEnd="url(#arrowhead)"
                        />
                        <text
                          x="52"
                          y="30"
                          textAnchor="start"
                          fontSize="2"
                          className="fill-emerald-500 font-black uppercase tracking-widest"
                        >
                          Continue
                        </text>
                      </svg>
                    </div>
                  )}

                  {step.id === "decision-master" && (
                    <>
                      <div className="col-span-3 h-2 relative" />
                      <div className="col-span-3 relative">
                        <div className="absolute left-1/2 top-0 w-px h-12 bg-emerald-400/30" />
                        <div className="absolute left-1/2 top-12 -translate-x-1/2 px-3 py-1.5 bg-emerald-100 text-[10px] font-bold text-emerald-700 rounded-md border border-emerald-200 shadow-sm whitespace-nowrap">
                          YES: Master exists → Skip to Review
                        </div>
                      </div>
                      <div className="col-span-3 h-8 relative" />
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <footer className="mt-20 flex flex-col items-center">
          <div className="bg-slate-900 rounded-[32px] p-12 text-white flex flex-col md:flex-row items-center gap-12 w-full shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
            <div className="relative z-10 flex-1">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 flex items-center justify-center border border-indigo-500/30">
                  <CheckCircle2 className="w-8 h-8 text-indigo-400" />
                </div>
                <h3 className="text-3xl font-black uppercase tracking-tight">
                  Active Lifecycle
                </h3>
              </div>
              <p className="text-slate-400 text-lg leading-relaxed max-w-xl">
                The subscription is now activated. Standard
                operations like{" "}
                <span className="text-white font-bold">
                  Invoicing
                </span>
                ,{" "}
                <span className="text-white font-bold">
                  Payments
                </span>
                , and{" "}
                <span className="text-white font-bold">
                  Renewals
                </span>{" "}
                are handled by the core engine.
              </p>
            </div>
            <div className="relative z-10 flex flex-col gap-4 bg-white/5 p-8 rounded-3xl border border-white/10 backdrop-blur-md">
              <div className="flex items-center gap-4">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <div className="text-sm font-black uppercase tracking-widest text-slate-300">
                  Live Status: Active
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6 mt-2">
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">
                    Invoices
                  </div>
                  <div className="text-lg font-bold">
                    Automated
                  </div>
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">
                    Retention
                  </div>
                  <div className="text-lg font-bold">
                    Auto-Renew
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-12 text-slate-400 text-[10px] font-black uppercase tracking-widest opacity-50">
            Subscription Billing Flow Diagram • March 2026
          </div>
        </footer>
      </div>
    </div>
  );
}