Create a vertical swimlane process flow diagram for a Contract-to-Subscription workflow inside a subscription billing system.

Use three swimlanes (left to right):

User (Billing / Revenue Ops)

System (Application)

AI Extraction Engine

The diagram must:

Be vertically structured (top to bottom)

Avoid crossing arrows

Clearly show decision points

Show AI involvement only before activation

Show human verification before activation

Show that the Draft is created immediately inside the Subscriptions module

Use the following shape rules:

Rounded rectangles = User actions

Rectangles = System actions

Diamonds = Decision points

Parallelogram = Data storage

Flow sequence:

USER LANE:

Navigate to Contracts module

Upload signed contract PDF

SYSTEM LANE:
3. Securely store contract (parallelogram)
4. Send contract to AI Extraction Engine

AI LANE:
5. Extract subscription-related terms:

Customer

Plan

Quantity

Billing Frequency

Start Date

End Date

Pricing

Discounts

Return structured data to System

SYSTEM LANE:
7. Immediately create Draft Subscription record inside Subscriptions module
(Status: Draft – Not Active, Pre-filled with extracted data)
8. Redirect user to Draft Subscription page in Subscriptions module
9. Highlight skeptical / ambiguous fields

DECISION (SYSTEM LANE):
10. Diamond: “Mandatory data missing?”
- Yes → Prompt user to enter missing data → Return to draft
- No → Continue

DECISION (SYSTEM LANE):
11. Diamond: “Master data exists?”
- No → Suggest create customer/plan → Redirect → Return to draft
- Yes → Continue

USER LANE:
12. Review pre-filled fields
13. View contract PDF side-by-side with highlighted keywords
14. Click “Confirm & Create Subscription”

SYSTEM LANE:
15. Convert Draft → Active Subscription
16. Begin standard subscription lifecycle:
- Invoicing
- Payments
- Renewals
17. Store contract as read-only reference linked to subscription

Add visual notes:

“AI involvement ends after Draft creation”

“Human confirmation required before activation”

“Existing subscription lifecycle reused”