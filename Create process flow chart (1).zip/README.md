
  # Create process flow chart

  This is a code bundle for Create process flow chart. The original project is available at https://www.figma.com/design/VTZY1eKF7gYmOv1hhNVEHD/Create-process-flow-chart.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  